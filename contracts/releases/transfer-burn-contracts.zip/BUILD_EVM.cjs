const fs = require('node:fs'), path = require('node:path'), crypto = require('node:crypto'), solc = require('solc');
const manifest = JSON.parse(fs.readFileSync('manifest.json', 'utf8'));
const sha = bytes => crypto.createHash('sha256').update(bytes).digest('hex');
if (solc.version() !== manifest.compilation.evm.compiler || require('@openzeppelin/contracts/package.json').version !== '5.6.1') throw Error('Install the pinned compiler and OpenZeppelin versions.');
for (const file of manifest.files) if (sha(fs.readFileSync(file.path)) !== file.sha256) throw Error('Source bytes changed: ' + file.path);
const all = {};
for (const group of manifest.compilation.evm.groups) {
  const sources = Object.fromEntries(group.entries.map(name => [name, { content: fs.readFileSync(name, 'utf8') }]));
  const settings = { ...manifest.compilation.evm.settings, outputSelection: { '*': { '*': ['abi', 'evm.bytecode.object', 'evm.deployedBytecode.object', 'evm.deployedBytecode.immutableReferences'] } } };
  const output = JSON.parse(solc.compile(JSON.stringify({ language: 'Solidity', sources, settings }), { import: name => {
    if (!['@openzeppelin/contracts/', 'contracts/v2/', 'contracts/v3/', 'contracts/token/'].some(prefix => name.startsWith(prefix)) || !name.endsWith('.sol') || name.split('/').includes('..')) return { error: 'Unexpected source import' };
    try { const file = name.startsWith('@') ? require.resolve(name, { paths: [process.cwd()] }) : name;
      const bytes = fs.readFileSync(file), expected = manifest.compilation.evm.sourceHashes[name];
      if (!expected || sha(bytes) !== expected) return { error: 'Compiler dependency differs: ' + name };
      return { contents: bytes.toString('utf8') };
    } catch { return { error: 'Install the pinned dependencies first: ' + name }; }
  } }));
  for (const message of output.errors || []) console.log(message.formattedMessage);
  if ((output.errors || []).some(message => message.severity === 'error')) throw Error('Compilation failed.');
  for (const target of group.targets) {
    const artifact = output.contracts[target.source][target.contract];
    if (sha(Buffer.from(artifact.evm.bytecode.object, 'hex')) !== target.creationBytecodeSha256 || sha(Buffer.from(artifact.evm.deployedBytecode.object, 'hex')) !== target.runtimeTemplateSha256) throw Error('Recorded bytecode differs: ' + target.contract);
    all[target.contract] = artifact;
  }
}
fs.mkdirSync('build', { recursive: true }); fs.writeFileSync('build/evm.json', JSON.stringify(all));
console.log(JSON.stringify({ pass: true, compiler: solc.version(), reproduced: Object.keys(all) }));
