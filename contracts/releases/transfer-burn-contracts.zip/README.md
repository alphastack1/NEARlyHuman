# NEARlyHuman generation 3 contract source

Reviewed contract sources for the current transfer-burn testnet generation. The download includes the Robinhood V3 controller and NHC token, the reused V2 verifier/action module, and the native NEAR V3 contract with its unchanged game kernel. The frozen V2 controller is included to reproduce the original interpreter compilation; it is not the current Robinhood controller.

NHC has six decimals. When enabled, ordinary address transfers burn floor(gross / 200) units (0.5%). The protocol owner can turn this fixed rate on or off. Purse withdrawals debit gross and deliver net. Productive issuance and the direct 250-NHC birth burns are supply operations without an additional transfer fee. Native NEAR transfer-call reserves the prospective fee and refunds unused portions after the receiver resolves.

## Files and verification

manifest.json lists each source's byte size, SHA256, readable URL, compiler settings, dependency hashes, artifact fingerprints and selected public deployment identifiers. Sources retain their original bytes and line endings. This archive excludes application code, wallet material, service records, operator scripts and test-only harnesses.

The native upgrade keeps the same account, NFTs and storage. Robinhood generation 3 is a separate collection; the original collection remains accessible by its original address. No bridge or shared balance is implied. The original source download remains at /source/contracts.zip with SHA256 96eb30080976baf50f386e131e338ad69d8575c410210fa55fe2cfeb85e83053.

## Reproduce EVM bytecode

Use Node 24 or newer. From this extracted directory:

    npm install --ignore-scripts
    node BUILD_EVM.cjs

The dependency manifest pins solc 0.8.38 and OpenZeppelin Contracts 5.6.1. Settings are optimizer enabled, one run, viaIR and Cancun. The helper checks the exact input/dependency hashes and reproduces both creation bytecode and unpatched runtime templates for the V3 controller/token and the reused verifier/module/types. Output goes to build/evm.json. Runtime templates contain immutable placeholders; the onchain code hashes identify the deployed instances. No wallet or blockchain access occurs.

The reviewed V3 artifact was compiled alongside a local test harness. Its fingerprint retains that fixture input's hash as provenance, but the harness is not a production dependency or archive entry. The helper independently verifies that this public source set reproduces the release contracts' exact bytecode.

## Reproduce native NEAR Wasm

Install Rust 1.95.0 with rust-src and wasm32-unknown-unknown, then run from this directory (POSIX shell):

    rustup toolchain install 1.95.0 --component rust-src --target wasm32-unknown-unknown
    RUSTC_BOOTSTRAP=1 RUSTFLAGS="--cfg near" cargo +1.95.0 build --locked --manifest-path contracts/near-v3/Cargo.toml --target wasm32-unknown-unknown -Z build-std=std,panic_abort --release

The Cargo manifest pins near-sdk and near-contract-standards 5.30.0 and hex 0.4.3; Cargo.lock pins transitive dependencies. The release profile uses one codegen unit, opt-level z, LTO, panic abort, overflow checks and stripped symbols. Compare target/wasm32-unknown-unknown/release/nearlyhuman_near_v3.wasm with manifest.json's SHA256 and byte size. The unchanged kernel remains at contracts/near/src/kernel.rs so the original relative module path works. Test harnesses are excluded; cargo test is not an archive command.

## Public reference records

Collection/account addresses, code hashes and deployment transactions in manifest.json come from the checked-in confirmed testnet records. Exporting verifies source/artifact fingerprints offline; it does not make a new RPC observation or constitute a security audit. The game uses a trusted AI relay, with legal state changes and economic outcomes checked by the contracts.
