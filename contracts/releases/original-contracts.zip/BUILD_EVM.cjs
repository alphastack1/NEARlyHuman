const fs = require('node:fs'), path = require('node:path'), solc = require('solc');
if (!solc.version().startsWith('0.8.38+') || require('@openzeppelin/contracts/package.json').version !== '5.6.1') throw Error('Install the pinned compiler and OpenZeppelin versions from package.json.');
const files = ['IV2LifeVerifier.sol','NEARlyHumanV2.sol','V2ActionModule.sol','V2LifeVerifier.sol','V2Types.sol'];
const sources = Object.fromEntries(files.map(name => ['contracts/v2/' + name, { content: fs.readFileSync('contracts/v2/' + name, 'utf8') }]));
const settings = { optimizer: { enabled: true, runs: 1 }, viaIR: true, evmVersion: 'cancun', outputSelection: { '*': { '*': ['abi','evm.bytecode.object','evm.deployedBytecode.object'] } } };
const output = JSON.parse(solc.compile(JSON.stringify({language:'Solidity',sources,settings}), { import: name => {
  if (!name.startsWith('@openzeppelin/contracts/') || !name.endsWith('.sol') || name.split('/').includes('..')) return { error: 'Unexpected source import' };
  try { return { contents: fs.readFileSync(require.resolve(name, {paths:[process.cwd()]}), 'utf8') }; } catch { return { error: 'Install the pinned dependencies first' }; }
} }));
for (const message of output.errors || []) console.log(message.formattedMessage);
if ((output.errors || []).some(message => message.severity === 'error')) process.exitCode = 1;
else { fs.mkdirSync('build', {recursive:true}); fs.writeFileSync('build/evm.json', JSON.stringify(output)); console.log('Compiled ' + solc.version()); }
