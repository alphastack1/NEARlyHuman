# NEARlyHuman smart-contract source

This download contains only the game's reviewed contract source snapshot, public compiler settings and deployment identifiers. It does not contain the full application repository, operator scripts, credentials, wallet material, service records or Git history. Source publication is not a security audit or a promise of trustless AI.

## Contents

- Five Solidity source files in contracts/v2. The NFT controller also defines the six-decimal NHC token.
- Native NEAR production contract and deterministic kernel in contracts/near/src, plus its pinned Cargo manifest and lockfile.
- manifest.json: exact source byte sizes and SHA256 values, compiler configuration and reference testnet identifiers. Files are copied byte-for-byte, retaining original line endings.

Both networks are testnets. Lives, inventory and token balances remain separate; there is no bridge. The contract verifies legal state and rewards while a trusted relay calls Jev and supplies delegated decisions.

## Build Robinhood/EVM contracts

Use Node24 or newer. From this extracted directory run:

    npm install
    node BUILD_EVM.cjs

The package manifest pins solc0.8.38 and OpenZeppelin Contracts5.6.1. The build uses optimizer1, via-IR and Cancun, preserving the repository's source paths. Generated compiler output is written to build/evm.json. The compiler command never deploys, requests wallet access or calls a blockchain. Dependency installation fetches pinned public packages; OpenZeppelin retains its upstream license.

## Build the native NEAR contract

The reference artifact used Rust1.95.0, near-sdk5.30.0, the wasm32-unknown-unknown target, cfg near and the release profile in Cargo.toml. With that Rust toolchain and rust-src installed, the repository's reference build is:

    RUSTC_BOOTSTRAP=1 RUSTFLAGS="--cfg near" cargo +1.95.0 build --locked --manifest-path contracts/near/Cargo.toml --target wasm32-unknown-unknown -Z build-std=std,panic_abort --release

The production source is included. The separate test harness is not part of this contracts-only archive, so cargo test is not an advertised archive command. Testnet source/code hashes in manifest.json are reference records from the project, not fresh RPC observations made by this export.

## Inspect the deployed worlds

Use the collection and explorer links in manifest.json or the website's Contracts & official links guide. Current payment amounts and network fees are shown in the app before signing. Do not send mainnet funds to a testnet address.
